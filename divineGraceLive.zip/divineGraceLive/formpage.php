<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Divine Grace Infotech</title>
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <!-- Optional theme -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <link rel="stylesheet" href="form.css" >
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="customDivine.css" rel="stylesheet" />
        <link href="customDivine2.css" rel="stylesheet" />
        <script src="form.js"></script>
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="main.js"></script>
    </head>
    <body >

            <!--CODES FOR HEADER AND NAVIGATION BAR -->
    
    <div class="navbar navbar-inverse navbar-fixed-top" style=" margin-top: -20px; background: #000080;">

        <div class="well well-sm" style="background: blue; color: white; border: none;">
            <div style="margin-left: 50px; margin-bottom: -13px; margin-top: 15px;">
                <h6><span class="glyphicon glyphicon-envelope">info@dgitech.epizy.com, support@dgitech.epizy.com  <span class="glyphicon glyphicon-earphone">0803-245-3815, 0815-629-9742</span></span></h6>
            </div>
        </div>

        <div class="container col-sm-12" style="margin-top: -20px;">    
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#collapse" aria-expanded="false">
                    <span class="sr-only">navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                
                <a href="#" class="navbar-brand"><img class="img-responsive" src="images/dgitLogo1.png" style="height: 40px; width: 40px; margin-top: -10px; " />
                    <h4 style="margin-left: 50px; margin-top: -29px; color: red; text-shadow: 1.5px 1px yellow, 0 0 9px white;">
                        <strong>DIVINE GRACE INFOTECH</strong>
                    </h4>
                </a>

            </div>
        <div class="collapse navbar-collapse" id="collapse">
            <ul class="nav navbar-nav">
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About Us</a></li>
                <li class="active"><a href="formpage.php">Contact Us</a></li>               
            </ul>

        </div>
    </div>
</div>

<p></p>br></p>
<p></p>br></p>

<!-- contact form section -->

        <div class="container">
            <div class="row">

             <div class="panel panel-primary"> <!--Panel-default, panel-info, -->
              <div class="panel-body">

                <div class="col-md-6" id="form_container">
                    <h3 style="color: red;" class="btn btn-lg btn-success" id="animatn3">Contact Form</h3> 
                    <p> Please send your message below. We will get back to you at the earliest! </p>
                    <form role="form" method="post" id="reused_form">
                        <div class="row">
                            <div class="col-sm-12 form-group">
                                <label for="message"> Message:</label>
                                <textarea class="form-control" type="textarea" id="message" name="message" maxlength="6000" rows="7"></textarea>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6 form-group">
                                <label for="name"> Your Name:</label>
                                <input type="text" class="form-control" id="name" name="name" required>
                            </div>
                            <div class="col-sm-6 form-group">
                                <label for="email"> Email:</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12 form-group">
                                <button type="submit" class="btn btn-lg btn-primary pull-right" >Send &rarr;</button>
                            </div>
                        </div>
                    </form>
                    <div id="success_message" style="width:100%; height:100%; display:none; "> 
                        <div class='alert alert-info'>
                             <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                             <b>Your message was delivered successfully! You will be contacted soonest.</b>
                        </div>
                    </div>
                    <div id="error_message" style="width:100%; height:100%; display:none; "> <h3>Error</h3> Sorry there was an error sending your form. </div>
                </div>                           

<br />
<!-- Company contact details -->

                    <div class="container">
                        <div class="row">
                            <div class="col-sm-6">
                                <div style="background-color: #BFEFFF; margin-bottom:3px; min-height:450px;
                                    background-color:#BFEFFF; font-size:25px; font-family:pristina;">
                                    <br/>
                                    <marquee style="color:red;">The Company's Contact Details</marquee>
                                    
                                    <p>Our highly esteemed customers worldwide, you can do well to contact us through the followings:</p>
                                     <p><h3 style="color:red;">Contact numbers:</h3> 0803-245-3815, 0815-629-9742</p> 
                                     <p><h3 style="color:red;">Email:</h3> info@dgitech.epizy.com, support@dgitech.epizy.com</p>
                                     <p style="color: red;">The company's headquarters address is shown below:</p>
                                     <p>Block 1, Abesan Estate, </br>
                                       Iyana Opaja, Lagos State,</br> 
                                       Nigeria</p>                                   
                                    
                                </div>
                             </div>
                        </div>
                    </div>
          </div>
        </div>
      </div>
    </div>

    <!--Code For footer is in "footer.php" using server-side include method-->

<?php include 'includes/footer.php'; ?>

    </body>
</html>