<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>DIVINE GRACE INFOTECH</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="customDivine.css" rel="stylesheet" />
	<link href="customDivine2.css" rel="stylesheet" />
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="main.js"></script>

  </head>

  <body>

		

			<!--CODES FOR HEADER AND NAVIGATION BAR -->
	
	<div class="navbar navbar-inverse navbar-fixed-top" style=" margin-top: -20px; background: #000080;">

		<div class="well well-sm" style="background: blue; color: white; border: none;">
			<div style="margin-left: 50px; margin-bottom: -13px; margin-top: 15px;">
				<h6><span class="glyphicon glyphicon-envelope">info@dgitech.epizy.com, support@dgitech.epizy.com  <span class="glyphicon glyphicon-earphone">0803-245-3815, 0815-629-9742</span></span></h6>
			</div>
			<div style="float: right; margin-top: -12px; margin-right: 90px;">
				<a href="http://www.facebook.com"><img src="images/facebook.jpg" style="width: 15px; height: 15px;" /></a>
				<a href="http://www.gmail.com"><img src="images/gmail.jpg" style="width: 15px; height: 15px;" /></a>
				<a href="http://www.youtube.com"><img src="images/youtube.jpg" style="width: 15px; height: 15px;" /></a>
				<a href="http://www.twitter.com"><img src="images/twitter.jpg" style="width: 15px; height: 15px;" /></a>
			</div>
		</div>

		<div class="container col-sm-12" style="margin-top: -20px;">	
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#collapse" aria-expanded="false">
					<span class="sr-only">navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				
				<a href="#" class="navbar-brand"><img class="img-responsive" src="images/dgitLogo1.png" style="height: 40px; width: 40px; margin-top: -10px; " />
					<h4 style="margin-left: 50px; margin-top: -29px; color: red; text-shadow: 1.5px 1px yellow, 0 0 9px white;">
						<strong>DIVINE GRACE INFOTECH</strong>
					</h4>
				</a>

			</div>
		<div class="collapse navbar-collapse" id="collapse">
			<ul class="nav navbar-nav">
				<li><a href="index.php">Home</a></li>
				<li class="active"><a href="about.php">About Us</a></li>
				<li><a href="formpage.php">Contact Us</a></li>				
			</ul>

		</div>
	</div>
</div>

<p></p>br></p>
<p></p>br></p> 


<!--<div class="wrapper"> -->

		
	<!--Code For jumbotron that contain vision, mission statement, and aim. -->
	
			<div class="container">
				<div class="jumbotron" style="background: #B0E2FF;">
					<p class="btn btn-lg btn-primary" id="animatn1"><strong>Our Vision</strong></p>			
					<p style="font-size: 16px;">
						Our vision is to provide a world-class, robbust, efficient, quality driven innovative services and creativity motivated design in professional web designs, Content Management Systems (CMS), software developments, networking, graphic designs that are customer focused and user friendly as well as CCTV installations and PBX Intercom installations.
					</p>

					<p class="btn btn-lg btn-success" id="animatn2"><strong>Our Mission</strong></p>
					<p style="font-size: 18px;">
					 	To consistently meet and exceed clients’ expectations by providing world-class solutions through our professionals and highly motivated ICT gurus, delivering excellent jobs in all fields of ICT to our amiable, efficient and valued clients globally.
					</p>

					<p class="btn btn-lg btn-primary"><strong>Our Work Philosophy</strong></p>
					<p style="font-size: 18px;">
						A succesful design or any ICT job demands a conceptual clarity and ability to visualize the overall solution within the periphery of specific industry domains and their business processes.<br>
					 	The technical team at Divine Grace Infotech is a seasoned group of professionals who can visualize the most complex client requirements and can translate them into a simplistic and aesthetic solution - a corporate ICT solutions that will help announce your arrival on the scene.
					 	</br>					 	
					</p>
				 </div>
			</div>

			<div class="container">
				<div class="jumbotron" style="background: #FFF0F5;">
					<!--Code For SECTION that contain FOUNDER'S PIX AND SPEECH -->

					<img src="images/ceo23.JPG" class="pull-left img-thumbnail img-responsive" style="width:155px; height: 170px; margin-left: 0px;" /><!--center-block, pull-left, pull-right-->
						
					<h3 style="color: #8B008B;"><b>Director's Speech</b></h3>
					<p style="font-size: 16px;">
						I welcome everyone to our official website. Divine Grace Infotech is an innovative-driven enterprise providing ICT solutions that are scalable, proven, secure, robust, efficient, easy to use as well as support. Our goal is to provide a world-class, robbust, efficient, quality driven innovative services and creativity motivated design in professional web designs, e-commerce, school portals, online store, Content Management Systems (CMS), software developments, networking, graphic designs that are customer focused and user friendly as well as computer repairs, CCTV installations and PBX Intercom installations. We are committed to delivering technologies that help our clients run more profitable businesses, and discover better ways to achieve their business goals and objectives.	
					</p>
					<p style="color: #9B30FF;">Our Core Values</p>
					<p style="font-size: 16px;">
						Our core values are team spirit, integrity, commitment, uniqueness and passion. The belief in our core values enables us to consistently meet and exceed clients’ expectations by providing world-class solutions through our professionals and highly motivated ICT gurus, delivering excellent jobs in all fields of ICT to our amiable, efficient and valued clients nationwide. We pride ourselves on the enviable marks of honesty, truthfulness and competence, thereby providing ICT products and services that are comparable with the best obtainable anywhere in the world.<br>
						Finally, I am appealing to you to trust us with your result-driven ICT jobs and achieve the best.					
					</p>

				</div>	
			</div>


	<!--Code For footer is in "footer.php" using server-side include method-->

<?php include 'includes/footer.php'; ?>



			<script src="js/jquery.min.js"></script>
  		<script src="js/bootstrap.min.js"></script>
		
    </body>
</html>
