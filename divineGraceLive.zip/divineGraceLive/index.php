<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>DIVINE GRACE INFOTECH</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.min.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
	<link href="customDivine.css" rel="stylesheet" />
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="main.js"></script>

  </head>

  <body>

			<!--CODES FOR HEADER AND NAVIGATION BAR -->
	
	<div class="navbar navbar-inverse navbar-fixed-top" style=" margin-top: -20px; background: #000080;">

		<div class="well well-sm" style="background: blue; color: white; border: none;">
			<div style="margin-left: 50px; margin-bottom: -13px; margin-top: 15px;">
				<h6><span class="glyphicon glyphicon-envelope">info@dgitech.epizy.com, support@dgitech.epizy.com  <span class="glyphicon glyphicon-earphone">0803-245-3815, 0815-629-9742</span></span></h6>
			</div>
			<div style="float: right; margin-top: -12px; margin-right: 90px;">
				<a href="http://www.facebook.com"><img src="images/facebook.jpg" style="width: 15px; height: 15px;" /></a>
				<a href="http://www.gmail.com"><img src="images/gmail.jpg" style="width: 15px; height: 15px;" /></a>
				<a href="http://www.youtube.com"><img src="images/youtube.jpg" style="width: 15px; height: 15px;" /></a>
				<a href="http://www.twitter.com"><img src="images/twitter.jpg" style="width: 15px; height: 15px;" /></a>
			</div>
		</div>

		<div class="container col-sm-12" style="margin-top: -20px;">	
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#collapse" aria-expanded="false">
					<span class="sr-only">navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				
				<a href="#" class="navbar-brand"><img class="img-responsive" src="images/dgitLogo1.png" style="height: 40px; width: 40px; margin-top: -10px; " />
					<h4 style="margin-left: 50px; margin-top: -29px; color: red; text-shadow: 1.5px 1px yellow, 0 0 9px white;">
						<strong>DIVINE GRACE INFOTECH</strong>
					</h4>
				</a>

			</div>
		<div class="collapse navbar-collapse" id="collapse">
			<ul class="nav navbar-nav">
				<li class="active"><a href="index.php">Home</a></li>
				<li><a href="about.php">About Us</a></li>
				<li><a href="formpage.php">Contact Us</a></li>				
			</ul>

		</div>
	</div>
</div>

<p></p>br></p>
<p></p>br></p> 


<!--<div class="wrapper"> -->

		<!--Code for Column Picture slide show-->

<div class="container">
	<div class="row">

	 <div class="panel panel-primary"> <!--Panel-default, panel-info, -->
	   <div class="panel-body">

		<div class="col-sm-12"> 
						
			<div id="my-slider" class="carousel slide" data-ride="carousel">
				
				<!--indicators dot nov-->
				<ol class="carousel-indicators">
					<li data-target="#my-slider" data-slide-to="0" class="active"></li>
					<li data-target="#my-slider" data-slide-to="1"></li>
					<li data-target="#my-slider" data-slide-to="2"></li>
					<li data-target="#my-slider" data-slide-to="3"></li>
					<li data-target="#my-slider" data-slide-to="4"></li>
					<li data-target="#my-slider" data-slide-to="5"></li>			
				</ol>
				
				<!--wrapper for slides-->
				
				<div class="carousel-inner" role="listbox">
					<div class="item active">
						<img src="images/d91.JPG" alt="d9" />
						<div class="carousel-caption">
							<h5 style="color: red;">ROBUST PARENT TEACHER PORTAL</h5>
						</div>
					</div>
					<div class="item">
						<img src="images/d11.JPG" alt="d11" />
						<div class="carousel-caption">
							<h5 style="color: red;">ROBUST PARENT TEACHER PORTAL</h5>
						</div>
					</div>
					<div class="item">
						<img src="images/d6.JPG" alt="d6" />
						<div class="carousel-caption">
							<h5 style="color: red;">E-COMMERCE WEBSITE</h5>
						</div>
					</div>
					<div class="item">
						<img src="images/d2.JPG" alt="d2" />
						<div class="carousel-caption">
							<h5 style="color: red;">FASHION DESIGN, CAKES AND EVENT DECORATION WEBSITE</h5>
						</div>
					</div>
					<div class="item">
						<img src="images/d51.JPG" alt="d5" />
						<div class="carousel-caption">
							<h5 style="color: red;">RESTORATION DRAMA MINISTRY WEBSITE</h5>
						</div>
					</div>
					<div class="item">
						<img src="images/d1.JPG" alt="d1" />
						<div class="carousel-caption">
							<h5 style="color: red;">MACFINH NIGERIA LIMITED WEBSITE</h5>
						</div>
					</div>

				</div>

				<!--controls or next and prev buttons-->

				<a class="left carousel-control" href="#my-slider" role="button" data-slide="prev">
					<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
					<span class="sr-only">Previous</span>
				</a>
				<a class="right carousel-control" href="#my-slider" role="button" data-slide="next">
					<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
					<span class="sr-only">Previous</span>
				</a>

			</div>			
		
		</div>
	  </div>
	</div>		
  </div>				
</div>

		
<!--Code for Column of my Portfolio-->
<div class="container">
		<div class="row">

			<div class="panel panel-primary"> <!--Panel-default, panel-info, -->
			  <div class="panel panel-heading">OUR PORTFOLIO</div>
				<div class="panel-body">


					<div class="col-sm-6">
						<div style="margin-bottom:3px; min-height:350px; background-color:#FFFFFF; text-align:center; font-size:17px; font-family:pristina; color: Black;">
							<b>E-COMMERCE WEBSITE</b>
							<div>
								<a href="https://bisiyemo.000webhostapp.com"><img src="images/d6.jpg" class="img-responsive" style="height: 300px; width: 600px; margin-left: 0px;" /></a>
							</div>
						</div>
					</div> <br/>

					<div class="col-sm-6">
						<div style="margin-bottom:3px; min-height:350px; background-color:#FFFFFF; text-align:center; font-size:17px; font-family:pristina; color: Black;">
							<b>E-COMMERCE WEBSITE</b>
							<div>
								<a href="https://bisiyemo.000webhostapp.com"><img src="images/d7.jpg" class="img-responsive" style="height: 300px; width: 600px; margin-left: 0px;" /></a>
							</div>
						</div>
					</div> <br/>

					<div class="col-sm-6">
						<div style="margin-bottom:3px; min-height:350px; background-color:#FFFFFF; text-align:center; font-size:17px; font-family:pristina; color: Black;">
							<b>E-COMMERCE WEBSITE</b>
							<div>
								<a href="https://bisiyemo.000webhostapp.com"><img src="images/d8.jpg" class="img-responsive" style="height: 300px; width: 600px; margin-left: 0px;" /></a>
							</div>
						</div>
					</div> <br/>

					<div class="col-sm-6">
						<div style="margin-bottom:3px; min-height:350px; background-color:#FFFFFF; text-align:center; font-size:17px; font-family:pristina; color: Black;">
							<b>MACFINH NIGERIA LIMITED WEBSITE</b>
							<div>
								<a href="https://macfinh.000webhostapp.com"><img src="images/d1.jpg" class="img-responsive" style="height: 300px; width: 600px; margin-left: 0px;" /></a>
							</div>
						</div>
					</div> <br/>

					<div class="col-sm-6">
						<div style="margin-bottom:3px; min-height:350px; background-color:#FFFFFF; text-align:center; font-size:17px; font-family:pristina; color: Black;">
							<b>VIRTUOSO OLA WORLD WEBSITE</b>
							<div>
								<a href="https://virtuosworld.000webhostapp.com"><img src="images/d2.jpg" class="img-responsive" style="height: 300px; width: 600px; margin-left: 0px;" />
							</div>
						</div>
					</div> <br/>

					<div class="col-sm-6">
						<div style="margin-bottom:3px; min-height:350px; background-color:#FFFFFF; text-align:center; font-size:17px; font-family:pristina; color: Black;">
							<b>VIRTUOSO OLA WORLD WEBSITE</b>
							<div>
								<a href="https://virtuosworld.000webhostapp.com"><img src="images/d3.jpg" class="img-responsive" style="height: 300px; width: 600px; margin-left: 0px;" /></a>
							</div>
						</div>
					</div> <br/>


					<div class="col-sm-6">
						<div style="margin-bottom:3px; min-height:350px; background-color:#FFFFFF; text-align:center; font-size:17px; font-family:pristina; color: Black;">
							<b>PARENT TEACHER PORTAL , TEACHERS PORTAL PAGE</b>
							<div>
								<a href="#"><img src="images/d101.jpg" class="img-responsive" style="height: 300px; width: 600px; margin-left: 0px;" /></a>
							</div>
						</div>
					</div> <br/>


					<div class="col-sm-6">
						<div style="margin-bottom:3px; min-height:350px; background-color:#FFFFFF; text-align:center; font-size:17px; font-family:pristina; color: Black;">
							<b>RESTORATION DRAMA MINISTRY WEBSITE</b>
							<div>
								<a href="#"><img src="images/d51.jpg" class="img-responsive" style="height: 300px; width: 600px; margin-left: 0px;" /></a>
							</div>
						</div>
					</div>	<br/>																			
					</div>
				</div>
			</div>
		</div>				
	</div>
			
	<!--Code for Column of about, gallery and contact links-->

		<div class="container">
				<div class="row">
					<div class="col-sm-4">
						<div style=" border-radius: 25px; background: #73AD21; padding: 20px; width: 350px; height: 250px; text-align:center; font-size:25px; font-family:pristina;   box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.5), 0 6px 20px 0 rgba(0, 0, 0, 0.25);">
							
							<h3><a style="color: white;">Home</a></h3>Home page is specially design to viewing a few of our world-class jobs, the impacts we have made globally and..."<a href="index.php" style="color: blue;">more</a>"
						</div>
					</div>
					<div class="col-sm-4">
						<div style=" border-radius: 25px; background: #73AD21; padding: 20px; width: 350px; height: 250px; text-align:center; font-size:25px; font-family:pristina;   box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.5), 0 6px 20px 0 rgba(0, 0, 0, 0.25);">
							
							<h3><a style="color: white;">About Us</a></h3> "About page is specially design to know us better, what we stand for, vision, mission, our impact globally and..."<a href="about.php" style="color: blue;">more</a>"
						</div>
					</div>
					<div class="col-sm-4">
						<div style=" border-radius: 25px; background: #73AD21; padding: 20px; width: 350px; height: 250px; text-align:center; font-size:25px; font-family:pristina;   box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.5), 0 6px 20px 0 rgba(0, 0, 0, 0.25);">
							
							<h3><a style="color: white;">Contact Us</a></h3> "Contact page is specially design to give you easy access to get in touch with us, for enquiry about anything and..."<a href="formpage.php" style="color: blue;">more</a>"
						</div>
					</div>
				</div>
		</div>


	</div>				
</div>
		
<!--</div>-->


	<!--Code For footer is in "footer.php" using server-side include method-->

<?php include 'includes/footer.php'; ?>  


			<script src="js/jquery.min.js"></script>
  		<script src="js/bootstrap.min.js"></script>
		
   </body>
</html>